module.exports = {
    preset: ['default', {
        calc: true,
        discardComments: {
            removeAll: true,
        }
    }]
};