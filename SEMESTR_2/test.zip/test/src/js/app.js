import Log from './components/m-log.js';


Log('Hello World from JS');