function Log(msg){
    console.log(`%c${msg}`, 'color: red; font-size: 16px;');
}
export default Log;