module.exports = {
    root: "./src/html"
}